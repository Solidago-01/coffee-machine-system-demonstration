# Coffee Machine System Demonstration
# L Autumn Gnadinger 2024
# Prompt from Angela Yu's 100 Days of Code
# Accepted commands: drink name (espresso, latte, cappuccino),
#       report, off, coin name (quarter, dime, nickle, pennie).

from art import logo
import sys

# Init Machine
MENU = {
    "espresso": {
        "ingredients": {
            "water": 50,
            "coffee": 18,
        },
        "cost": 1.5,
    },
    "latte": {
        "ingredients": {
            "water": 200,
            "milk": 150,
            "coffee": 24,
        },
        "cost": 2.5,
    },
    "cappuccino": {
        "ingredients": {
            "water": 250,
            "milk": 100,
            "coffee": 24,
        },
        "cost": 3.0,
    }
}

resources = {
    "water": 300,  # in ml
    "milk": 200,  # in ml
    "coffee": 100,  # in grams
    "money": 0.00,  # in $USD
}

print(logo)

# Machine Running
machine_on = True
while machine_on:

    def compile_report():
        print("Here is your report: ")
        print("Water: " + str(resources.get("water")) + "ml")
        print("Milk: " + str(resources.get("milk")) + "ml")
        print("Coffee: " + str(resources.get("coffee")) + "g")
        print("Money: " + "$" + str(resources.get("money")))
        print("")

    def check_resources(requested_item):
        needed = MENU.get(requested_item).get("ingredients")
        inventory = []
        for x in needed:
            inventory.append(resources.get(x) - needed.get(x))
        if any(y < 0 for y in inventory):
            return False
        else:
            return True

    def ask_for_money(order):
        cost = (MENU.get(order).get("cost"))
        print(f"That will be ${cost}")
        customer_payment = 0
        print("Please insert Quarters, Nickels, Dimes, or Pennies one at a time.")
        awaiting_payment = True
        while awaiting_payment:
            if customer_payment > cost:
                refund = customer_payment - cost
                profit = customer_payment - refund
                print(f"Thank you. Here is your change: ${refund}")
                return profit
            elif customer_payment == cost:
                profit = customer_payment
                return profit
            else:
                coin = input(f"${cost-customer_payment} remaining. Insert coin: ")
                coin = coin.lower()
                if coin == "quarter":
                    customer_payment += .25
                elif coin == "nickel":
                    customer_payment += .05
                elif coin == "dime":
                    customer_payment += .10
                elif coin == "pennie":
                    customer_payment += .01
                else:
                    print("I'm sorry, try another coin.")

    def update_resources(order, profit):
        updated_r = resources
        for item in MENU.get(order).get("ingredients"):
            updated_r[item] -= MENU.get(order).get("ingredients")[item]
        updated_r["money"] += profit

    def ask_for_order():
        print("Welcome to the Coffee Machine!")
        print("")
        print("Here is our Menu:")
        for x in MENU:
            print(x.capitalize() + ": " + "$" + str(MENU.get(x).get("cost")))
        print("")
        order = input("What would you like?: ")
        order = order.lower()
        print("")
        if order == "espresso" or order == "latte" or order == "cappuccino":
            stock = check_resources(order)
            if stock:
                profit = ask_for_money(order)
                update_resources(order, profit)
                print("Thank you! Here is your drink: \u2615")
                print("")
            else:
                print("I'm sorry, we are sold out.")
        elif order == "off":
            print("Goodbye")
            sys.exit()
        elif order == "report":
            compile_report()
        else:
            print("I'm sorry, please try again.")

    ask_for_order()